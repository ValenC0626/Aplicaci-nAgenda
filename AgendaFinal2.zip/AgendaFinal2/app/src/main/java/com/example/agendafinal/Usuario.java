package com.example.agendafinal;
public class Usuario {
    private String id;
    private String nombre;
    private String apellido;
    private String documento;
    private String edad;
    private String telefono;
    private String direccion;
    private String fechaNacimiento;
    private String email;
    private String estadoCivil;
    private String preferencias;
    private String equipoFutbolFavorito;
    private String peliculaFavorita;
    private String colorFavorito;
    private String comidaFavorita;
    private String libroFavorito;
    private String cancionFavorita;
    private String descripcionPersonal;

    public Usuario(String id, String nombre, String apellido, String documento, String edad, String telefono, String direccion,
                   String fechaNacimiento, String email, String estadoCivil, String preferencias,
                   String equipoFutbolFavorito, String peliculaFavorita, String colorFavorito,
                   String comidaFavorita, String libroFavorito, String cancionFavorita, String descripcionPersonal) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.documento = documento;
        this.edad = edad;
        this.telefono = telefono;
        this.direccion = direccion;
        this.fechaNacimiento = fechaNacimiento;
        this.email = email;
        this.estadoCivil = estadoCivil;
        this.preferencias = preferencias;
        this.equipoFutbolFavorito = equipoFutbolFavorito;
        this.peliculaFavorita = peliculaFavorita;
        this.colorFavorito = colorFavorito;
        this.comidaFavorita = comidaFavorita;
        this.libroFavorito = libroFavorito;
        this.cancionFavorita = cancionFavorita;
        this.descripcionPersonal = descripcionPersonal;
    }

    // Getters and setters...

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getPreferencias() {
        return preferencias;
    }

    public void setPreferencias(String preferencias) {
        this.preferencias = preferencias;
    }

    public String getEquipoFutbolFavorito() {
        return equipoFutbolFavorito;
    }

    public void setEquipoFutbolFavorito(String equipoFutbolFavorito) {
        this.equipoFutbolFavorito = equipoFutbolFavorito;
    }

    public String getPeliculaFavorita() {
        return peliculaFavorita;
    }

    public void setPeliculaFavorita(String peliculaFavorita) {
        this.peliculaFavorita = peliculaFavorita;
    }

    public String getColorFavorito() {
        return colorFavorito;
    }

    public void setColorFavorito(String colorFavorito) {
        this.colorFavorito = colorFavorito;
    }

    public String getComidaFavorita() {
        return comidaFavorita;
    }

    public void setComidaFavorita(String comidaFavorita) {
        this.comidaFavorita = comidaFavorita;
    }

    public String getLibroFavorito() {
        return libroFavorito;
    }

    public void setLibroFavorito(String libroFavorito) {
        this.libroFavorito = libroFavorito;
    }

    public String getCancionFavorita() {
        return cancionFavorita;
    }

    public void setCancionFavorita(String cancionFavorita) {
        this.cancionFavorita = cancionFavorita;
    }

    public String getDescripcionPersonal() {
        return descripcionPersonal;
    }

    public void setDescripcionPersonal(String descripcionPersonal) {
        this.descripcionPersonal = descripcionPersonal;
    }
}
