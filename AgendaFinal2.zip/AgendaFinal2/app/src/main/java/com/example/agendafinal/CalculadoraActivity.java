package com.example.agendafinal;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class CalculadoraActivity extends AppCompatActivity {

    private TextView tvResultado;
    private StringBuilder currentInput = new StringBuilder();
    private double operand1 = 0;
    private String operator = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);

        tvResultado = findViewById(R.id.tvResultado);

        initializeButtons();
    }

    private void initializeButtons() {

        int[] numberButtons = {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3,
                R.id.btn4, R.id.btn5, R.id.btn6, R.id.btn7,
                R.id.btn8, R.id.btn9
        };

        for (int id : numberButtons) {
            Button button = findViewById(id);
            button.setOnClickListener(this::onNumberClick);
        }

        findViewById(R.id.btnSumar).setOnClickListener(v -> onOperatorClick("+"));
        findViewById(R.id.btnRestar).setOnClickListener(v -> onOperatorClick("-"));
        findViewById(R.id.btnMultiplicar).setOnClickListener(v -> onOperatorClick("*"));
        findViewById(R.id.btnDividir).setOnClickListener(v -> onOperatorClick("/"));
        findViewById(R.id.btnIgual).setOnClickListener(v -> onEqualClick());
        findViewById(R.id.btnC).setOnClickListener(v -> clear());

        findViewById(R.id.btnRegresar).setOnClickListener(v -> finish());
    }

    private void onNumberClick(View view) {
        Button button = (Button) view;
        currentInput.append(button.getText());
        tvResultado.setText(currentInput.toString());
    }

    private void onOperatorClick(String op) {
        if (currentInput.length() > 0) {
            operand1 = Double.parseDouble(currentInput.toString());
            operator = op;
            currentInput.setLength(0); // Clear current input for the next number
        }
    }

    private void onEqualClick() {
        if (currentInput.length() > 0 && !operator.isEmpty()) {
            double operand2 = Double.parseDouble(currentInput.toString());
            double result = 0;

            switch (operator) {
                case "+":
                    result = operand1 + operand2;
                    break;
                case "-":
                    result = operand1 - operand2;
                    break;
                case "*":
                    result = operand1 * operand2;
                    break;
                case "/":
                    if (operand2 != 0) {
                        result = operand1 / operand2;
                    } else {
                        tvResultado.setText("Error");
                        return;
                    }
                    break;
            }

            tvResultado.setText(String.valueOf(result));
            currentInput.setLength(0);
            operator = "";
        }
    }

    private void clear() {
        currentInput.setLength(0);
        tvResultado.setText("0");
        operand1 = 0;
        operator = "";
    }
}
