package com.example.agendafinal;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText etId, etNombre, etApellido, etDocumento, etEdad, etTelefono, etDireccion, etFechaNacimiento, etEmail,
            etPeliculaFavorita, etColorFavorito, etComidaFavorita, etLibroFavorito, etCancionFavorita,
            etDescripcionPersonal;
    Spinner spinnerTelefono, spinnerEmail, spinnerEquipoFutbol;
    RadioGroup radioGroupEstadoCivil;
    CheckBox cbMusica, cbDeporte, cbCine, cbComida, cbViajes, cbLibros;

    List<Usuario> usuarios = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etId = findViewById(R.id.etId);
        etNombre = findViewById(R.id.etNombre);
        etApellido = findViewById(R.id.etApellido);
        etDocumento = findViewById(R.id.etDocumento);
        etEdad = findViewById(R.id.etEdad);
        etTelefono = findViewById(R.id.etTelefono);
        etDireccion = findViewById(R.id.etDireccion);
        etFechaNacimiento = findViewById(R.id.etFechaNacimiento);
        etEmail = findViewById(R.id.etEmail);
        radioGroupEstadoCivil = findViewById(R.id.radioGroupEstadoCivil);
        spinnerTelefono = findViewById(R.id.spinnerTelefono);
        spinnerEmail = findViewById(R.id.spinnerEmail);
        spinnerEquipoFutbol = findViewById(R.id.spinnerEquipoFutbol);
        etPeliculaFavorita = findViewById(R.id.etPeliculaFavorita);
        etColorFavorito = findViewById(R.id.etColorFavorito);
        etComidaFavorita = findViewById(R.id.etComidaFavorita);
        etLibroFavorito = findViewById(R.id.etLibroFavorito);
        etCancionFavorita = findViewById(R.id.etCancionFavorita);
        etDescripcionPersonal = findViewById(R.id.etDescripcionPersonal);
        cbMusica = findViewById(R.id.cbMusica);
        cbDeporte = findViewById(R.id.cbDeporte);
        cbCine = findViewById(R.id.cbCine);
        cbComida = findViewById(R.id.cbComida);
        cbViajes = findViewById(R.id.cbViajes);
        cbLibros = findViewById(R.id.cbLibros);

        configurarSpinners();
    }

    private void configurarSpinners() {
        String[] tiposTelefono = {"Personal", "Laboral", "Privado"};
        ArrayAdapter<String> adapterTelefono = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tiposTelefono);
        adapterTelefono.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTelefono.setAdapter(adapterTelefono);

        String[] tiposEmail = {"Personal", "Laboral", "Privado"};
        ArrayAdapter<String> adapterEmail = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tiposEmail);
        adapterEmail.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEmail.setAdapter(adapterEmail);

        String[] equiposFutbol = {"Cali", "América", "Nacional", "Millonarios"};
        ArrayAdapter<String> adapterEquipos = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, equiposFutbol);
        adapterEquipos.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEquipoFutbol.setAdapter(adapterEquipos);
    }

    public void guardarUsuario(View v) {
        String id = etId.getText().toString();
        String nombre = etNombre.getText().toString();
        String apellido = etApellido.getText().toString();
        String documento = etDocumento.getText().toString();
        String edad = etEdad.getText().toString();
        String telefono = etTelefono.getText().toString();
        String direccion = etDireccion.getText().toString();
        String fechaNacimiento = etFechaNacimiento.getText().toString();
        String email = etEmail.getText().toString();

        int idEstadoCivilSeleccionado = radioGroupEstadoCivil.getCheckedRadioButtonId();
        RadioButton rbEstadoCivilSeleccionado = findViewById(idEstadoCivilSeleccionado);
        String estadoCivil = rbEstadoCivilSeleccionado != null ? rbEstadoCivilSeleccionado.getText().toString() : "No seleccionado";

        StringBuilder preferencias = new StringBuilder();
        if (cbMusica.isChecked()) preferencias.append("Música ");
        if (cbDeporte.isChecked()) preferencias.append("Deporte ");
        if (cbCine.isChecked()) preferencias.append("Cine ");
        if (cbComida.isChecked()) preferencias.append("Comida ");
        if (cbViajes.isChecked()) preferencias.append("Viajes ");
        if (cbLibros.isChecked()) preferencias.append("Libros ");

        String equipoFutbolFavorito = spinnerEquipoFutbol.getSelectedItem().toString();
        String peliculaFavorita = etPeliculaFavorita.getText().toString();
        String colorFavorito = etColorFavorito.getText().toString();
        String comidaFavorita = etComidaFavorita.getText().toString();
        String libroFavorito = etLibroFavorito.getText().toString();
        String cancionFavorita = etCancionFavorita.getText().toString();
        String descripcionPersonal = etDescripcionPersonal.getText().toString();

        Usuario usuario = new Usuario(id, nombre, apellido, documento, edad, telefono, direccion, fechaNacimiento, email,
                estadoCivil, preferencias.toString().trim(), equipoFutbolFavorito, peliculaFavorita,
                colorFavorito, comidaFavorita, libroFavorito, cancionFavorita, descripcionPersonal);
        usuarios.add(usuario);

        Toast.makeText(this, "Usuario guardado: " + nombre, Toast.LENGTH_SHORT).show();
        limpiarCampos();
    }

    public void buscarUsuario(View v) {
        String id = etId.getText().toString();
        for (Usuario usuario : usuarios) {
            if (usuario.getId().equals(id)) {
                llenarCampos(usuario);
                return;
            }
        }
        Toast.makeText(this, "Usuario no encontrado", Toast.LENGTH_SHORT).show();
    }

    private void llenarCampos(Usuario usuario) {
        etNombre.setText(usuario.getNombre());
        etApellido.setText(usuario.getApellido());
        etDocumento.setText(usuario.getDocumento());
        etEdad.setText(usuario.getEdad());
        etTelefono.setText(usuario.getTelefono());
        etDireccion.setText(usuario.getDireccion());
        etFechaNacimiento.setText(usuario.getFechaNacimiento());
        etEmail.setText(usuario.getEmail());

        switch (usuario.getEstadoCivil()) {
            case "Soltero":
                radioGroupEstadoCivil.check(R.id.radioSoltero);
                break;
            case "Casado":
                radioGroupEstadoCivil.check(R.id.radioCasado);
                break;
            case "Divorciado":
                radioGroupEstadoCivil.check(R.id.radioDivorciado);
                break;
        }

        cbMusica.setChecked(usuario.getPreferencias().contains("Música"));
        cbDeporte.setChecked(usuario.getPreferencias().contains("Deporte"));
        cbCine.setChecked(usuario.getPreferencias().contains("Cine"));
        cbComida.setChecked(usuario.getPreferencias().contains("Comida"));
        cbViajes.setChecked(usuario.getPreferencias().contains("Viajes"));
        cbLibros.setChecked(usuario.getPreferencias().contains("Libros"));

        spinnerEquipoFutbol.setSelection(((ArrayAdapter<String>) spinnerEquipoFutbol.getAdapter()).getPosition(usuario.getEquipoFutbolFavorito()));
        etPeliculaFavorita.setText(usuario.getPeliculaFavorita());
        etColorFavorito.setText(usuario.getColorFavorito());
        etComidaFavorita.setText(usuario.getComidaFavorita());
        etLibroFavorito.setText(usuario.getLibroFavorito());
        etCancionFavorita.setText(usuario.getCancionFavorita());
        etDescripcionPersonal.setText(usuario.getDescripcionPersonal());
    }

    public void modificarUsuario(View v) {
        String id = etId.getText().toString();
        for (Usuario usuario : usuarios) {
            if (usuario.getId().equals(id)) {
                actualizarUsuario(usuario);
                Toast.makeText(this, "Usuario modificado: " + usuario.getNombre(), Toast.LENGTH_SHORT).show();
                limpiarCampos();
                return;
            }
        }
        Toast.makeText(this, "Usuario no encontrado", Toast.LENGTH_SHORT).show();
    }

    private void actualizarUsuario(Usuario usuario) {
        usuario.setNombre(etNombre.getText().toString());
        usuario.setApellido(etApellido.getText().toString());
        usuario.setDocumento(etDocumento.getText().toString());
        usuario.setEdad(etEdad.getText().toString());
        usuario.setTelefono(etTelefono.getText().toString());
        usuario.setDireccion(etDireccion.getText().toString());
        usuario.setFechaNacimiento(etFechaNacimiento.getText().toString());
        usuario.setEmail(etEmail.getText().toString());

        int idEstadoCivilSeleccionado = radioGroupEstadoCivil.getCheckedRadioButtonId();
        RadioButton rbEstadoCivilSeleccionado = findViewById(idEstadoCivilSeleccionado);
        usuario.setEstadoCivil(rbEstadoCivilSeleccionado != null ? rbEstadoCivilSeleccionado.getText().toString() : "No seleccionado");

        StringBuilder preferencias = new StringBuilder();
        if (cbMusica.isChecked()) preferencias.append("Música ");
        if (cbDeporte.isChecked()) preferencias.append("Deporte ");
        if (cbCine.isChecked()) preferencias.append("Cine ");
        if (cbComida.isChecked()) preferencias.append("Comida ");
        if (cbViajes.isChecked()) preferencias.append("Viajes ");
        if (cbLibros.isChecked()) preferencias.append("Libros ");

        usuario.setPreferencias(preferencias.toString().trim());
        usuario.setEquipoFutbolFavorito(spinnerEquipoFutbol.getSelectedItem().toString());
        usuario.setPeliculaFavorita(etPeliculaFavorita.getText().toString());
        usuario.setColorFavorito(etColorFavorito.getText().toString());
        usuario.setComidaFavorita(etComidaFavorita.getText().toString());
        usuario.setLibroFavorito(etLibroFavorito.getText().toString());
        usuario.setCancionFavorita(etCancionFavorita.getText().toString());
        usuario.setDescripcionPersonal(etDescripcionPersonal.getText().toString());
    }

    public void eliminarUsuario(View v) {
        String id = etId.getText().toString();
        for (Usuario usuario : usuarios) {
            if (usuario.getId().equals(id)) {
                usuarios.remove(usuario);
                Toast.makeText(this, "Usuario eliminado: " + usuario.getNombre(), Toast.LENGTH_SHORT).show();
                limpiarCampos();
                return;
            }
        }
        Toast.makeText(this, "Usuario no encontrado", Toast.LENGTH_SHORT).show();
    }

    private void limpiarCampos() {
        etId.setText("");
        etNombre.setText("");
        etApellido.setText("");
        etDocumento.setText("");
        etEdad.setText("");
        etTelefono.setText("");
        etDireccion.setText("");
        etFechaNacimiento.setText("");
        etEmail.setText("");
        radioGroupEstadoCivil.clearCheck();
        cbMusica.setChecked(false);
        cbDeporte.setChecked(false);
        cbCine.setChecked(false);
        cbComida.setChecked(false);
        cbViajes.setChecked(false);
        cbLibros.setChecked(false);
        etPeliculaFavorita.setText("");
        etColorFavorito.setText("");
        etComidaFavorita.setText("");
        etLibroFavorito.setText("");
        etCancionFavorita.setText("");
        etDescripcionPersonal.setText("");
    }

    public void abrirCalculadora(View v) {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_APP_CALCULATOR);
        startActivity(intent);
    }

    public void regresarAGenda(View v) {
        finish();
    }
}
